var searchData=
[
  ['_7ereport_0',['~Report',['../structs_reader_1_1_report.html#a4c33cf40cb8a27d8f88a35dadb270a55',1,'sReader::Report']]],
  ['_7eresult_1',['~Result',['../structs_reader_1_1_result.html#a89829f5acd45739786576ea9132f862f',1,'sReader::Result']]]
];
