var searchData=
[
  ['tariff_0',['tariff',['../structs_reader_1_1_taxes.html#a147164dc0d68c45f37c694c81b5316be',1,'sReader::Taxes']]],
  ['taxes_1',['Taxes',['../structs_reader_1_1_taxes.html',1,'sReader']]],
  ['taxes_2',['taxes',['../structs_reader_1_1_result.html#a76c79c3547181c72cdd6e61dcff683c8',1,'sReader::Result']]],
  ['taxes_5fcount_3',['taxes_count',['../structs_reader_1_1_result.html#a916c91efecc0f0a54eb2a08f87cb4248',1,'sReader::Result']]],
  ['taxes_5fname_4',['taxes_name',['../structs_reader_1_1_query.html#a3d6baf73e6ea0c05ed9f8d5a16232282',1,'sReader::Query']]]
];
