var searchData=
[
  ['name_0',['name',['../structs_reader_1_1_taxes.html#a311da17d5b68524a58a0f862228b4882',1,'sReader::Taxes']]],
  ['number_1',['number',['../structs_reader_1_1_taxes.html#a7106e2abc437ad981830d14176d15f09',1,'sReader::Taxes::number()'],['../structs_reader_1_1_flat.html#a7106e2abc437ad981830d14176d15f09',1,'sReader::Flat::number()']]]
];
