var searchData=
[
  ['flat_0',['flat',['../structs_reader_1_1_record___i_m_d.html#ab04f214feff6f4910ab05d6be5994cf5',1,'sReader::Record_IMD::flat()'],['../structs_reader_1_1_query.html#ab04f214feff6f4910ab05d6be5994cf5',1,'sReader::Query::flat()']]],
  ['flats_1',['flats',['../structs_reader_1_1_result.html#a29843fa79ccb957ca29465f6122f9dfc',1,'sReader::Result']]],
  ['flats_5fcount_2',['flats_count',['../structs_reader_1_1_result.html#a31773ba5dedcc797d2c0dcfd877c61cf',1,'sReader::Result']]],
  ['fsum_3',['fsum',['../structs_reader_1_1_record___report.html#a3d56f7afd6d662d730ae4e6020714d7c',1,'sReader::Record_Report::fsum()'],['../structs_reader_1_1_report.html#a3d56f7afd6d662d730ae4e6020714d7c',1,'sReader::Report::fsum()']]],
  ['fsum_5fcost_4',['fsum_cost',['../structs_reader_1_1_record___report.html#a3e41168f06deae256e411cd135b5e323',1,'sReader::Record_Report::fsum_cost()'],['../structs_reader_1_1_report.html#a3e41168f06deae256e411cd135b5e323',1,'sReader::Report::fsum_cost()']]]
];
