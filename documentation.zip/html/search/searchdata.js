var indexSectionsWithContent =
{
  0: "cfgilmnopqrstw~б",
  1: "fqrt",
  2: "s",
  3: "fprs",
  4: "ir~",
  5: "cfgilmnoqst",
  6: "fw",
  7: "б"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Структуры данных",
  2: "Пространства имен",
  3: "Файлы",
  4: "Функции",
  5: "Переменные",
  6: "Макросы",
  7: "Страницы"
};

