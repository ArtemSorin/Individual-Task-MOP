var searchData=
[
  ['query_0',['Query',['../structs_reader_1_1_query.html',1,'sReader']]]
];
