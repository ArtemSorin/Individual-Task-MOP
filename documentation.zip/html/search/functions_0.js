var searchData=
[
  ['init_0',['Init',['../namespaces_reader.html#a068be0f137d5f6a8a69cb8b811a2846b',1,'sReader']]]
];
