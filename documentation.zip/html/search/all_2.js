var searchData=
[
  ['ghmd_0',['ghmd',['../structs_reader_1_1_result.html#a847bb549d0222dae7d7bfbe403e2d6b5',1,'sReader::Result']]],
  ['ghmd_5fcount_1',['ghmd_count',['../structs_reader_1_1_result.html#aed39248605798ede50966311f5acf4b5',1,'sReader::Result']]],
  ['gs_2',['gS',['../structs_reader_1_1_result.html#ad1adc3590fb9fa50e39294c8579f9d38',1,'sReader::Result']]]
];
