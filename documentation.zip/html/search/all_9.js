var searchData=
[
  ['query_0',['query',['../structs_reader_1_1_result.html#aee16b3a9d7acb1e0464a872350e10d23',1,'sReader::Result']]],
  ['query_1',['Query',['../structs_reader_1_1_query.html',1,'sReader']]]
];
