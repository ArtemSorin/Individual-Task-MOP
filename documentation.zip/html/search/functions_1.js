var searchData=
[
  ['readdetails_0',['readDetails',['../namespaces_reader.html#a46eb97db87d23fe6b2bea12c810743aa',1,'sReader']]],
  ['readhome_1',['readHome',['../namespaces_reader.html#afc378650f62e6635a68e6cf860e266f7',1,'sReader']]],
  ['readtaxes_2',['readTaxes',['../namespaces_reader.html#af8c1eac5740d5cbed208d0ec33ab7507',1,'sReader']]]
];
