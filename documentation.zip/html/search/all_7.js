var searchData=
[
  ['odn_0',['odn',['../structs_reader_1_1_record___report.html#a329597415bcbfa84377f0a9df3642edd',1,'sReader::Record_Report::odn()'],['../structs_reader_1_1_report.html#a329597415bcbfa84377f0a9df3642edd',1,'sReader::Report::odn()']]],
  ['odn_5fcost_1',['odn_cost',['../structs_reader_1_1_record___report.html#af1ecc978b1d7810b76f22eb04f98f869',1,'sReader::Record_Report::odn_cost()'],['../structs_reader_1_1_report.html#af1ecc978b1d7810b76f22eb04f98f869',1,'sReader::Report::odn_cost()']]]
];
