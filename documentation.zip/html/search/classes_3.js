var searchData=
[
  ['taxes_0',['Taxes',['../structs_reader_1_1_taxes.html',1,'sReader']]]
];
