var searchData=
[
  ['sreader_0',['sReader',['../namespaces_reader.html',1,'']]]
];
