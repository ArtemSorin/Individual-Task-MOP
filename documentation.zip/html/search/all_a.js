var searchData=
[
  ['readdetails_0',['readDetails',['../namespaces_reader.html#a46eb97db87d23fe6b2bea12c810743aa',1,'sReader']]],
  ['readfiles_2eh_1',['readfiles.h',['../readfiles_8h.html',1,'']]],
  ['readhome_2',['readHome',['../namespaces_reader.html#afc378650f62e6635a68e6cf860e266f7',1,'sReader']]],
  ['readme_2eh_3',['Readme.h',['../_readme_8h.html',1,'']]],
  ['readtaxes_4',['readTaxes',['../namespaces_reader.html#af8c1eac5740d5cbed208d0ec33ab7507',1,'sReader']]],
  ['record_5fghmd_5',['Record_GHMD',['../structs_reader_1_1_record___g_h_m_d.html',1,'sReader']]],
  ['record_5fimd_6',['Record_IMD',['../structs_reader_1_1_record___i_m_d.html',1,'sReader']]],
  ['record_5freport_7',['Record_Report',['../structs_reader_1_1_record___report.html',1,'sReader']]],
  ['report_8',['Report',['../structs_reader_1_1_report.html',1,'sReader']]],
  ['result_9',['Result',['../structs_reader_1_1_result.html',1,'sReader']]]
];
